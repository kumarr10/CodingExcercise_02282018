﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace LatestPriceCalculator
{
    class Program
    {
        const Int32 BufferSize = 128;
        static void Main(string[] args)
        {
            string sourceFilename = @".\Files\priceticks.txt";
            string targetFilename = @".\Files\Output.txt";
            string tobewritten = string.Empty;
         
            using (var fileStream = File.OpenRead(sourceFilename))
            {
                using (var streamReader = new StreamReader(fileStream, Encoding.UTF8, true, BufferSize))
                {
                    using (StreamWriter outFile = new StreamWriter(targetFilename,true,Encoding.UTF8,BufferSize))
                    {
                        string currLine;
                        while (( currLine = streamReader.ReadLine()) != null)
                        {
                            if (CheckAlphanumeric(currLine))
                            {
                                if (!string.IsNullOrEmpty(tobewritten))
                                {
                                    outFile.WriteLine(tobewritten);
                                    outFile.WriteLine(currLine);
                                }
                                else
                                {
                                    outFile.WriteLine(currLine);
                                }
                            }
                            else
                            {
                                tobewritten = currLine;
                            }
                        }
                        outFile.WriteLine(tobewritten);
                    }
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="currLine"></param>
        /// <returns></returns>
        private static bool CheckAlphanumeric(string currLine)
        {
            return currLine.All(c => Char.IsLetterOrDigit(c));
        }        
    }
}
